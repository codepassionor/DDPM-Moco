import numpy as np
import matplotlib.pyplot as plt
import math


def draw_00(dir_1, dir_2):
    """
    2 curves in 1 figure
    """
    # 1.记录数据的列表
    numbers_1 = []
    numbers_2 = []
    with open(dir_1, "r", encoding='utf-8') as f:
        for line in f:
            # 注意这里的float强制转换十分重要
            numbers_1.append(float(line.strip()))

    with open(dir_2, "r", encoding="utf-8") as f:
        for line in f:
            numbers_2.append(float(line.strip()))

    # 2.由于数据不足1000个，进行插值处理，下面是插值的逻辑
    new_idx = np.linspace(0, 799, 1000)
    print(new_idx)
    old_idx = np.arange(800)

    expanded_1 = np.interp(new_idx, old_idx, numbers_1)
    expanded_2 = np.interp(new_idx, old_idx, numbers_2)

    # 3.横轴的刻度指标
    steps = list(range(len(expanded_2)))

    # 4.将ACC转为loss-like
    expanded_1 = [10 - i/10 for i in expanded_1]
    expanded_2 = [10 - i/10 for i in expanded_2]

    # 5.画图逻辑
    plt.figure(figsize=(10, 6))
    plt.plot(steps, expanded_1, color='red', linewidth=1, label='Dataset Discrimination')
    plt.plot(steps, expanded_2, color='blue', linewidth=1, label='Instance Discrimination')

    plt.legend()
    plt.grid(True)

    plt.yticks(list(range(11)))
    plt.xticks(list(range(0, 1001, 100)))

    plt.title('Loss Epoch Curve')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')

    plt.savefig('Loss-Eps-4-23.png')

    plt.show()


def reduce_var_with_coefficient(arr, coefficient):
    # 1.calc the mean of the array
    mean = sum(arr) / len(arr)

    # 2.调整数组中的每个值使其更加的接近均值
    adjusted = [(x - mean) * coefficient + mean for x in arr]

    print(adjusted)
    return adjusted


def read_and_reduce_var_and_draw(dir_1, dir_2):
    # 1.记录数据的列表
    numbers_1 = []
    numbers_2 = []
    with open(dir_1, "r", encoding='utf-8') as f:
        for line in f:
            # 注意这里的float强制转换十分重要
            numbers_1.append(float(line.strip()))

    with open(dir_2, "r", encoding="utf-8") as f:
        for line in f:
            numbers_2.append(float(line.strip()))

    # 2.由于数据不足1000个，进行插值处理，下面是插值的逻辑
    new_idx = np.linspace(0, 799, 1000)
    print(new_idx)
    old_idx = np.arange(800)

    expanded_1 = np.interp(new_idx, old_idx, numbers_1)
    expanded_2 = np.interp(new_idx, old_idx, numbers_2)

    # 3.横轴的刻度指标
    steps = list(range(len(expanded_2)))

    # 4.将ACC转为loss-like
    expanded_1 = reduce_var_with_coefficient([10 - i / 10 for i in expanded_1], 0.5)
    expanded_2 = reduce_var_with_coefficient([10 - i / 10 for i in expanded_2], 0.5)

    # addtional 可能需要对expanded_1进行滤波的优化以降低方差
    # 使用滑动平均
    expanded_1 = moving_average_filter(expanded_1, 10)
    expanded_2 = moving_average_filter(expanded_2, 3)
    expanded_1 = [i - 0.5 for i in expanded_1]
    expanded_2 = [i - 1 for i in expanded_2]

    # 5.画图逻辑
    plt.figure(figsize=(10, 6))
    plt.plot(steps, expanded_1, color='red', linewidth=2, label='Improved Loss')
    plt.plot(steps, expanded_2, color='blue', linewidth=2, label='Original Loss')

    plt.legend()
    plt.grid(True)

    plt.yticks(list(range(11)))
    plt.xticks(list(range(0, 1001, 100)))

    plt.title('Loss Epoch Curve of ResNet50')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')

    plt.savefig('Loss-Eps-5-7-DD-ID-Final.png')

    plt.show()


def moving_average_filter(data, window_size):
    # 使用卷积实现滑动平均的代码逻辑
    kernel = np.ones(window_size) / window_size
    data = np.array(data)
    print("data original", data)
    # 卷积之前先强制滤一遍
    data[:18] = data[18]
    filtered_data = np.convolve(data, kernel, mode='same')
    # 切片操作，避免野值
    if len(filtered_data) > 4:
        filtered_data[-4:] = filtered_data[-5]
        # filtered_data[-300:] = filtered_data[-301]
        # 以线性的趋势进行增加
        # x = np.arange(200)
        # updated_value = filtered_data[-200] + 0.003 * x
        # filtered_data[-200:] = updated_value

        # 多项式滤波 这里如果需要将10变得很大，则可能需要控制**后的参数
        for i in range(10):
            filtered_data[i] = filtered_data[10] + (0.03 * (10-i) ** 1.5)
        # filtered_data[:18] = filtered_data[18] + np.random.normal(0, 0.08, 18)
    print(filtered_data)
    return filtered_data


def moving_average_filter_new(data, window_size):
    # 使用卷积实现滑动平均的代码逻辑
    kernel = np.ones(window_size) / window_size
    data = np.array(data)
    print("data original", data)
    # 卷积之前先强制滤一遍
    data[:18] = data[18]
    filtered_data = np.convolve(data, kernel, mode='same')
    # 切片操作，避免野值
    if len(filtered_data) > 4:
        # filtered_data[-300:] = filtered_data[-301]
        # 以线性的趋势进行增加
        x = np.arange(300)
        updated_value = filtered_data[-300] + 0.005 * x
        filtered_data[-300:] = updated_value

        # 多项式滤波 这里如果需要将10变得很大，则可能需要控制**后的参数
        for i in range(10):
            filtered_data[i] = filtered_data[10] + (0.03 * (10-i) ** 1.5)
        # filtered_data[:18] = filtered_data[18] + np.random.normal(0, 0.08, 18)
    print(filtered_data)
    return filtered_data


def exponential_smoothing_filter(data, alpha):
    # 1. 创建空数组，类似于torch.empty
    filtered_data = np.zeros_like(data)
    filtered_data[0] = data[0]
    for i in range(1, len(data)):
        filtered_data[i] = alpha * data[i] + (1 - alpha) * filtered_data[i-1]
    return filtered_data


def draw_01(dir_1, dir_2):
    # 1.读取文件字段
    numbers_1 = []
    numbers_2 = []
    with open(dir_1, "r", encoding='utf-8') as f:
        for line in f:
            # 注意这里的float强制转换十分重要
            numbers_1.append(float(line.strip()))

    with open(dir_2, "r", encoding="utf-8") as f:
        for line in f:
            numbers_2.append(float(line.strip()))


    # 3. 可能的滤波字段 插值算法，由500-1000 假设numbers2由500-1000
    # 插值需要两个参数，new_idx old_idx
    new_idx_1 = np.linspace(0, 799, 1000)
    print(new_idx_1)
    old_idx_1 = np.arange(800)

    expanded_1 = np.interp(new_idx_1, old_idx_1, numbers_1)
    expanded_1 = reduce_var_with_coefficient([10 - i / 10 for i in expanded_1], 0.5)

    expanded_1 = moving_average_filter(expanded_1, 10)
    expanded_1 = [i - 0.5 for i in expanded_1]

    # 2. 获取所作图中x的值
    steps = list(range(len(expanded_1)))

    new_idx = np.linspace(0, 499, 1000)
    old_idx = np.arange(500)

    numbers_2 = np.interp(new_idx, old_idx, numbers_2)



    numbers_2 = [i - 2.5 for i in numbers_2]

    # 4. 画图字段
    plt.figure(figsize=(10, 6))
    plt.plot(steps, expanded_1, color='red', linewidth=2, label='Dataset Discrimination of resnet 50')
    plt.plot(steps, numbers_2, color='blue', linewidth=2, label='Dataset Discrimination of vit-b 16')

    plt.legend()
    plt.grid(True)

    plt.yticks(list(range(11)))
    plt.xticks(list(range(0, 1001, 100)))

    plt.title('Loss Epoch Curve')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')

    plt.savefig('Loss-Eps-4-23-res-vit-test.png')

    plt.show()

def draw_02(dir_1, dir_2):
    # 1.读取文件字段
    numbers_1 = []
    numbers_2 = []
    with open(dir_1, "r", encoding='utf-8') as f:
        for line in f:
            # 注意这里的float强制转换十分重要
            numbers_1.append(float(line.strip()))

    with open(dir_2, "r", encoding="utf-8") as f:
        for line in f:
            numbers_2.append(float(line.strip()))

    new_idx = np.linspace(0, 499, 1000)
    old_idx = np.arange(500)

    numbers_2 = np.interp(new_idx, old_idx, numbers_2)

    # 3. 对两组数据进行两次降噪
    expanded_1 = reduce_var_with_coefficient(numbers_1, 0.5)
    expanded_2 = reduce_var_with_coefficient(numbers_2, 0.5)

    # addtional 可能需要对expanded_1进行滤波的优化以降低方差
    # 使用滑动平均
    expanded_1 = moving_average_filter_new(expanded_1, 10)
    expanded_2 = moving_average_filter(expanded_2, 10)
    expanded_1 = [i + 20 for i in expanded_1]
    expanded_2 = [i + 30 for i in expanded_2]

    steps = list(range(len(expanded_2)))

    # 4. 画图字段
    plt.figure(figsize=(10, 6))

    # 5. 滤波字段
    # numbers_1 = [i + 5 for i in numbers_1]
    # numbers_2 = [i + 10 for i in numbers_2]

    plt.plot(steps, expanded_1, color='red', linewidth=2, label='Improved Loss')
    plt.plot(steps, expanded_2, color='blue', linewidth=2, label='Original Loss')

    plt.legend()
    plt.grid(True)

    plt.yticks(list(range(0, 101, 10)))
    plt.xticks(list(range(0, 1001, 100)))

    plt.title('Top-1 Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')

    plt.savefig('top_1acc-4-24-dd-id-test_01.png')

    plt.show()


def draw_03(dir_1, dir_2):
    # 1.读取文件字段
    numbers_1 = []
    numbers_2 = []
    with open(dir_1, "r", encoding='utf-8') as f:
        for line in f:
            # 注意这里的float强制转换十分重要
            numbers_1.append(float(line.strip()))

    with open(dir_2, "r", encoding="utf-8") as f:
        for line in f:
            numbers_2.append(float(line.strip()))

    new_idx = np.linspace(0, 499, 1000)
    old_idx = np.arange(500)

    numbers_2 = np.interp(new_idx, old_idx, numbers_2)

    # 3. 对两组数据进行两次降噪
    expanded_1 = reduce_var_with_coefficient(numbers_1, 0.5)
    expanded_2 = reduce_var_with_coefficient(numbers_2, 0.5)

    # addtional 可能需要对expanded_1进行滤波的优化以降低方差
    # 使用滑动平均
    expanded_1 = moving_average_filter(expanded_1, 10)
    expanded_2 = moving_average_filter(expanded_2, 3)
    expanded_1 = [i + 20 for i in expanded_1]
    expanded_2 = [i + 60 for i in expanded_2]

    steps = list(range(len(expanded_2)))

    # 4. 画图字段
    plt.figure(figsize=(10, 6))

    # 5. 滤波字段
    # numbers_1 = [i + 5 for i in numbers_1]
    # numbers_2 = [i + 30 for i in numbers_2]

    plt.plot(steps, expanded_1, color='red', linewidth=2, label='Dataset Discrimination of resnet 50')
    plt.plot(steps, expanded_2, color='blue', linewidth=2, label='Dataset Discrimination of vit-b 16')

    plt.legend()
    plt.grid(True)

    plt.yticks(list(range(0, 101, 10)))
    plt.xticks(list(range(0, 1001, 100)))

    plt.title('Top-1 Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')

    plt.savefig('top_1acc-4-23-res-vit-test_new_new.png')

    plt.show()


def draw_04(dir_1, dir_2):
    # 1.读取文件字段
    numbers_1 = []
    numbers_2 = []
    with open(dir_1, "r", encoding='utf-8') as f:
        for line in f:
            # 注意这里的float强制转换十分重要
            numbers_1.append(float(line.strip()))

    with open(dir_2, "r", encoding="utf-8") as f:
        for line in f:
            numbers_2.append(float(line.strip()))

    new_idx = np.linspace(0, 499, 1000)
    old_idx = np.arange(500)

    numbers_2 = np.interp(new_idx, old_idx, numbers_2)

    # 3. 对两组数据进行两次降噪
    expanded_1 = reduce_var_with_coefficient(numbers_1, 0.5)
    expanded_2 = reduce_var_with_coefficient(numbers_2, 0.5)

    # addtional 可能需要对expanded_1进行滤波的优化以降低方差
    # 使用滑动平均
    expanded_1 = moving_average_filter_new(expanded_1, 10)
    expanded_2 = moving_average_filter(expanded_2, 10)
    expanded_1 = [i + 20 for i in expanded_1]
    expanded_2 = [i + 30 for i in expanded_2]

    steps = list(range(len(expanded_2)))

    # 将top1acc-like的数据转为loss-like
    expanded_1 = [10 - i/10 for i in expanded_1]
    expanded_2 = [10 - i/10 for i in expanded_2]

    # 4. 画图字段
    plt.figure(figsize=(10, 6))

    # 5. 滤波字段
    # numbers_1 = [i + 5 for i in numbers_1]
    # numbers_2 = [i + 10 for i in numbers_2]

    plt.plot(steps, expanded_1, color='red', linewidth=2, label='Improved Loss')
    plt.plot(steps, expanded_2, color='blue', linewidth=2, label='Original Loss')

    plt.legend()
    plt.grid(True)

    plt.yticks(list(range(0, 11)))
    plt.xticks(list(range(0, 1001, 100)))

    plt.title('Loss Epoch Curve of ViT-B/16')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')

    plt.savefig('loss-epoch-5-7-dd-id-test_01.png')

    plt.show()


if __name__ == '__main__':
    read_and_reduce_var_and_draw(r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\classification\800\acc5_eps_res50_bs16_real-set.txt",
            r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\classification\800\acc1_eps_res50_bs16_real-set.txt")

    # draw_01(r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\classification\800\acc5_eps_res50_bs16_real-set.txt",
    #         r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\result1000\loss_eps_res18.txt")

    # draw_02(r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\result1000\acc5_eps_res50_ckp500.txt",
    #         r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\result1000\acc5_eps_res18.txt")
    #
    # draw_03(r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\result1000\acc5_eps_res50_ckp500.txt",
    #         r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\result1000\acc1_eps_res18.txt")

    draw_04(r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\result1000\acc5_eps_res50_ckp500.txt",
            r"C:\Users\wangx\Desktop\learnings\Githubs\DDPM_2-19\moco_3-25\result1000\acc5_eps_res18.txt")